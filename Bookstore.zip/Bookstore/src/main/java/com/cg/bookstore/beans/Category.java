package com.cg.bookstore.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Category {
	@Id
	String categoryName;
	@OneToMany
	List<Book> booksByCategory;
	
	public Category() {
		super();
	}
	public Category(String categoryName) {
		super();
		this.categoryName = categoryName;
	}
	
	public Category(String categoryName, List<Book> booksByCategory) {
		super();
		this.categoryName = categoryName;
		this.booksByCategory = booksByCategory;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public List<Book> getBooksByCategory() {
		return booksByCategory;
	}
	public void setBooksByCategory(List<Book> booksByCategory) {
		this.booksByCategory = booksByCategory;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((booksByCategory == null) ? 0 : booksByCategory.hashCode());
		result = prime * result + ((categoryName == null) ? 0 : categoryName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (booksByCategory == null) {
			if (other.booksByCategory != null)
				return false;
		} else if (!booksByCategory.equals(other.booksByCategory))
			return false;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Category [categoryName=" + categoryName + ", booksByCategory=" + booksByCategory + "]";
	}
}
