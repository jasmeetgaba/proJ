package com.cg.bookstore.daoservices;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.bookstore.beans.OrderItem;

public interface OrderDAO extends JpaRepository<OrderItem, Long>{
	@Query(value="from OrderItem o where o.customerId=:customerId")
	List<OrderItem> findAllOrders(@Param("customerId")String customerEmailId);
}
